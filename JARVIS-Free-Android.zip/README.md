# JARVIS Free Android

A no-API-key static voice + text assistant for Android Chrome.

## Free features
- Chat interface, voice input (if browser supports it), spoken replies
- Time/date, basic arithmetic, open YouTube/Maps/Gmail/WhatsApp Web, Google search
- No API key, server, subscription or payment

## Limitations
This is a basic command assistant, not a full general-purpose AI. No always-on wake word or background listening. Speech recognition depends on browser/device and may use an online speech service. Text input remains available.

## Publish free with GitHub Pages (phone only)
1. Create a free account at https://github.com/signup
2. Create a **public** repository named `jarvis-free`.
3. Upload the five files inside `public/` to the repository root: `index.html`, `app.js`, `style.css`, `manifest.webmanifest`, `sw.js`.
4. Open repository **Settings → Pages**.
5. Under Build and deployment choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for publishing. Open `https://YOUR-USERNAME.github.io/jarvis-free/` in Android Chrome.
7. Chrome menu (⋮) → Add to Home screen / Install app.

Keep passwords, private data and API keys out of the public repository. No credit card is needed for this public static site.
